#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Configuração do Display OLED (128x64)
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Definição dos pinos com base no novo diagram.json
#define TRIG_PIN 12   // Pino Trig do ultrassônico conectado ao D12[cite: 5]
#define ECHO_PIN 14   // Pino Echo do ultrassônico conectado ao D14[cite: 5]
#define SERVO_PIN 23  // Pino de sinal do Micro-servo conectado ao D23[cite: 5]
#define LED_PIN 4     // Pino do LED conectado ao D4[cite: 5]

Servo meuservo;

void setup() {
  Serial.begin(9600);
  
  // Configuração dos pinos
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  
  // Inicialização do Servo e estado inicial
  meuservo.attach(SERVO_PIN);
  meuservo.write(0);
  digitalWrite(LED_PIN, LOW);

  // Inicialização do display OLED (Endereço I2C 0x3C)[cite: 5]
  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Falha ao inicializar o OLED"));
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextColor(WHITE);
}

void loop() {
  long duration, distance;

  // Emitir pulso ultrassônico
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  // Medir o tempo de eco
  duration = pulseIn(ECHO_PIN, HIGH);

  // Calcular distância em centímetros
  distance = (duration / 2) * 0.0343;

  // Exibir no Monitor Serial
  Serial.print("Distancia: ");
  Serial.print(distance);
  Serial.println(" cm");

  // Lógica de acionamento (< 100 cm)
  if (distance < 100) {
    digitalWrite(LED_PIN, HIGH); // Acende o LED
    meuservo.write(90);          // Abre a cancela (90º)
  } else {
    digitalWrite(LED_PIN, LOW);  // Apaga o LED
    meuservo.write(0);           // Fecha a cancela (0º)
  }

  // Atualizar informações no Display OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("ESTACIONAMENTO");
  display.drawLine(0, 10, 128, 10, WHITE);

  display.setCursor(0, 20);
  display.print("Distancia: ");
  display.print(distance);
  display.println(" cm");

  display.setCursor(0, 40);
  if (distance < 100) {
    display.println("Status: CARRO DETECTADO");
    display.println("Cancela: ABERTA");
  } else {
    display.println("Status: LIVRE");
    display.println("Cancela: FECHADA");
  }
  
  display.display();

  delay(500);
}